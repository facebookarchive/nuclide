## 0.3.0
* snippets for println
* can properly toggle comments
* actually highlights strings and literals
* highlights functions

## 0.2.0
* highlight comments (nested)
* highlight additional keywords: final, internal, private, public
* started to fill out pattern repository; much of it not integrated yet

## 0.1.0 - First Release
* Very rough and basic syntax highlighting support
