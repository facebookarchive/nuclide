# Language support for Scala in Atom

[![apm](https://img.shields.io/apm/v/language-scala.svg?style=flat-square)](https://atom.io/packages/language-scala)
[![npm](https://img.shields.io/npm/v/language-scala.svg?style=flat-square)](https://www.npmjs.com/package/language-scala)

[Scala grammar](https://atom.io/packages/language-scala) for [Atom](https://atom.io). Originally converted from the [Scala TextMate bundle](https://github.com/mads379/scala.tmbundle). Also available as a [Node package](https://www.npmjs.com/package/language-scala).
