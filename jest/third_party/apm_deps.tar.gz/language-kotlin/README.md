# Kotlin language support in Atom

Adds syntax highlighting to Kotlin files in Atom. 

![Kotlin Atom Package Screenshoot](https://raw.githubusercontent.com/alexmt/atom-kotlin-language/master/sample.png)

Converted from [Sublime Text package](https://github.com/vkostyukov/kotlin-sublime-package) which has been implemented by [Vladimir Kostyukov](https://github.com/vkostyukov).
