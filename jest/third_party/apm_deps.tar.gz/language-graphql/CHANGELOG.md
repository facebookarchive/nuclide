## 0.6.0, 0.7.0

* Fix publishing on APM

## 0.5.0

* Add LICENSE to repo

## 0.4.0

* Fix `cmd + /` comments to use `#`

## 0.3.0

* Improve support for schema language
* Improve directive highlights

## 0.2.0

* Fix escaped characters in strings
* Highlight aliases

## 0.1.0 - First Release
* Simple GraphQL grammar
