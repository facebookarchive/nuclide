# language-thrift package

Atom syntax highlighting and snippets for [Thrift][thrift] files. Originally imported from [thrift.tmbundle][thrift-tmbundle]

![screenshot](https://i.cloudup.com/70mT3AJ1Go-3000x3000.png)

[thrift]: http://thrift.apache.org/
[thrift-tmbundle]: https://github.com/textmate/thrift.tmbundle
